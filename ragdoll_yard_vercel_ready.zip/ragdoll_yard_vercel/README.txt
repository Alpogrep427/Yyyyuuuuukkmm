RAGDOLL YARD - GITHUB + VERCEL DEPLOYMENT

Upload the CONTENTS of this folder to the root of your GitHub repository
(or to the Vercel Root Directory configured for your project).

Required structure:
  index.html
  models/
    fps_arms.glb

Do not upload only this ZIP. Extract it first and preserve the models folder.
Do not rename fps_arms.glb or the models folder: the HTML requests
./models/fps_arms.glb relative to index.html.

Vercel will serve index.html at the site root and the GLB at
/models/fps_arms.glb. No build command or framework preset is required
for this static HTML project. Commit/push to GitHub to trigger redeployment.

Original model: FREE [FPS Arms] GameReady - RIGGED
Author: BAMEN (https://sketchfab.com/bamenwo05)
Source: https://sketchfab.com/3d-models/free-fps-arms-gameready-rigged-296d30fc705b4dff85c2c8a2d2724e7f
License: CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/)
Credit the original author when redistributing the model.
